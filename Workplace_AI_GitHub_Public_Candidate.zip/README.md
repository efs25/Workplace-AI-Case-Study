# Workplace AI built around expert judgment

**Eric Sanders | Prairie Fire Partners**

A documentation case study of designing a software backbone around experienced practitioners: the information they need, the decisions they own and the work AI can help prepare.

## Start here

- [Workplace AI case study](docs/workplace-ai-case-study.pdf): operating thesis, context feedback, intelligence workflow, permissions, and financial/commercial coordination.
- [Fictional workflow examples](examples/workflow-examples.json): small illustrations of how context changes the correct response.

## The operating model

![Context and human judgment](assets/context.png)

Sources and project history inform preparation. Practitioners review interpretation, accept specific changes and determine what may be released. Accepted decisions and subsequent records refresh the context for later work.

![Intelligence workflow design](assets/intelligence.png)

The integrated design connects research and meeting insight with exact-version review and scoped delivery. The documents distinguish implemented components from integration objectives. This repository is a case study, not a deployable application or evidence that every depicted connection is live.

## Scope

The public material describes product ownership, workflow design and AI-assisted implementation. It includes no production source, credentials, client records, private financial information or deployment configuration. Examples are fictional and are not test receipts. No quantified productivity or revenue outcome is asserted.

The document displays an editorial document date in October 2026. This reviewed revision was prepared in November 2026; the date label is not a historical deployment claim.

## Contents

- `docs/`: reviewed PDF case studies.
- `assets/`: explanatory diagrams.
- `examples/`: fictional inputs and intended human-governed handling.

No executable code or installation is required. This documentation does not grant a software or content license beyond rights available under applicable law.
